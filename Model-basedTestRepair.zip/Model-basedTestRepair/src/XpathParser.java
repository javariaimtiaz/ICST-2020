import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.w3c.dom.Node;

public class XpathParser {

	private static String getXPath(Node root) {
		Node current = root;
		String output = "";
		while (current.getParentNode() != null) {
			Node parent = current.getParentNode();
			if (parent != null && parent.getChildNodes().getLength() > 1) {
				int nthChild = 1;
				Node siblingSearch = current;
				while ((siblingSearch = siblingSearch.getPreviousSibling()) != null) {
					// only count siblings of same type
					if (siblingSearch.getNodeName().equals(current.getNodeName())) {
						nthChild++;
					}
				}
				output = "/" + current.getNodeName() + "[" + nthChild + "]" + output;
			} else {
				output = "/" + current.getNodeName() + output;
			}
			current = current.getParentNode();
		}
		System.out.println("Path is:" + output);
		return output;
	}

	public static String xpathFinderFromFile(String attribute, String attribute_text, File file) {

		System.out.println(attribute + "=\"" + attribute_text + "\"");
		Document doc = null;
		try {
			doc = Jsoup.parse(file, "UTF-8");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Elements elements = doc.body().select("*");
		ArrayList all = new ArrayList();
		for (Element element : elements) {

			Elements element1;
			element1 = element.getElementsByAttributeValueMatching(attribute, attribute_text.replace("\"", ""));
			for (Element element2 : element1) {

				StringBuilder path = new StringBuilder(element2.nodeName());
				String value = element2.ownText();
				Elements p_el = element2.parents();
				String node = "";
				int count = 0;
				for (Element el : p_el) {
					path.insert(0, el.nodeName() + '/');
				}
				all.add(path + "[text()='" + value + "']");
				if (value.isEmpty()) {
					return path + "[@" + attribute + "='" + attribute_text.replace("\"", "") + "']";
				} else {
					return path + "[text()='" + value + "']";
				}

			}

//			if (!element.ownText().isEmpty()) {
//				=
//				System.out.println(attribute + "=" + attribute_text);
//				if (element.toString().contains(attribute + "=" + attribute_text)) {
//					System.out.println("hello000000000000000000000000");
//					StringBuilder path = new StringBuilder(element.nodeName());
//					String value = element.ownText();
//					Elements p_el = element.parents();
//					String node = "";
//					int count = 0;
//					for (Element el : p_el) {
//						path.insert(0, el.nodeName() + '/');
//					}
//					all.add(path + "[text()='" + value + "']");
//					System.out.println(path + "[text()='" + value + "']");
//					return path + "[text()='" + value + "']";
//				}
//			}

		}

		return "";

	}

	public static String getXpath(String ele) {
		String str = ele;
		String[] listString = null;
		if (str.contains("xpath"))
			listString = str.split("xpath:");
		else if (str.contains("id"))
			listString = str.split("id=");
		else if (str.contains("name"))
			listString = str.split("name=");
		else if (str.contains("class"))
			listString = str.split("class=");
		else if (str.contains("href"))
			listString = str.split("href=");
		else if (str.contains("type"))
			listString = str.split("type=");
		try {
			String last = listString[1].trim();
			return last.substring(0, last.length() - 1);
		} catch (Exception e) {
			return null;
		}
	}

	private static void test(Node node, Document doc) {

		String expression = null;
		try {
			expression = getXPath(node);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Node result = null;
		try

		{
			result = (Node) XPathFactory.newInstance().newXPath().compile(expression).evaluate(doc,
					XPathConstants.NODE);
		} catch (XPathExpressionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (result == node) {
			System.out.println("Test OK  : " + expression);
		} else {
			System.out.println("Test Fail: " + expression);
		}
		for (int i = 0; i < node.getChildNodes().getLength(); i++) {
			test(node.getChildNodes().item(i), doc);
		}
	}

	private static String fileToLines1(String filename) {

		StringBuilder stringBuilder = new StringBuilder();
		String ls = System.getProperty("line.separator");
		String line = "";
		try {
			BufferedReader in = new BufferedReader(new FileReader(filename));
			while ((line = in.readLine()) != null) {
				stringBuilder.append(line);
				stringBuilder.append(ls);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return stringBuilder.toString();
	}
}
//Document doc = Jsoup.parse(file);
// System.out.print(doc.getElementById("name").get);

/*
 * String stringBuilder = fileToLines1("D:\\collabtive_old\\collabtive61.html");
 * System.out.println("wdpwkdopkwodkowd"); try { Document root =
 * DocumentBuilderFactory.newInstance().newDocumentBuilder() .parse(new
 * File("D:\\collabtive_old\\collabtive61.html"));
 * 
 * test(root.getDocumentElement(), root); } catch (Exception e) {
 * e.printStackTrace(); }
 */