import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class JSoupConverter {
	public static void main(String args[]) {
		try {
			Document d = Jsoup.connect("D:/claroline").timeout(6000).get();
			Elements ele = d.select("");
			for(Element element:ele) {
				 
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
