/*
 * 
 */
package mdse.emf.main;

import java.util.ArrayList;

import org.eclipse.emf.common.util.EList;
import org.eclipse.uml2.uml.Enumeration;
import org.eclipse.uml2.uml.EnumerationLiteral;
import org.eclipse.uml2.uml.PackageableElement;
import org.eclipse.uml2.uml.Profile;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.Stereotype;
import org.eclipse.uml2.uml.UMLPackage;

import mdse.emf.main.EnumerationStructure;
import mdse.emf.main.EnumerationValue;
import mdse.emf.main.StereotypeAttribute;
import mdse.emf.main.StereotypeStructure;

// TODO: Auto-generated Javadoc
/**
 * The Class UMLProfileReader reads the UML profile.
 *
 * @author Javaria
 */

public class UMLProfileReader {

	/** The stereotypes describes the list of stereotypes in the UML profile. */
	private ArrayList<StereotypeStructure> stereotypes = new ArrayList<StereotypeStructure>();
	
	/** The enumerations describes the list of enumerations in the UML profile. */
	private ArrayList<EnumerationStructure> enumerations = new ArrayList<EnumerationStructure>();

	/**
	 * Gets the stereotypes instance.
	 *
	 * @return the stereotypes
	 */
	public ArrayList<StereotypeStructure> getStereotypes() {
		return stereotypes;
	}

	/**
	 * Gets the enumerations instance.
	 *
	 * @return the enumerations
	 */
	public ArrayList<EnumerationStructure> getEnumerations() {
		return enumerations;
	}

	/**
	 * Reads the UML profile to create instance of stereotypes and enumerations.
	 *
	 * @param profile the profile
	 * @throws Exception the exception
	 */
	public void readProfile(Profile profile) throws Exception {
		EList<PackageableElement> members = profile.getPackagedElements();
		for (PackageableElement element : members) {
			if (element.eClass() == UMLPackage.Literals.ENUMERATION) {
				Enumeration enumeration = (Enumeration) element;
				EnumerationStructure es = createEnumeration(enumeration);
				if(es != null)
					enumerations.add(es);
			} else if (element.eClass() == UMLPackage.Literals.STEREOTYPE) {
				Stereotype stereotype = (Stereotype) element;
				try{
				StereotypeStructure ss = createStereotype(stereotype);
				if(ss != null)
					stereotypes.add(ss);
				}catch(Exception e){
					System.out.println(e.getMessage());
				}
			}
		}
	}
	
	/**
	 * Creates the enumeration instance from the enumeration Node.
	 *
	 * @param enumeration the enumeration
	 * @return the enumeration structure
	 */
	private EnumerationStructure createEnumeration(Enumeration enumeration){
		EnumerationStructure es = new EnumerationStructure(enumeration.getLabel());
		EList<EnumerationLiteral> enumerationLiterals = enumeration.getOwnedLiterals();
		for (EnumerationLiteral literal : enumerationLiterals) {
			EnumerationValue ev = new EnumerationValue(literal.getLabel(), literal.getVisibility().getLiteral());
			es.addValue(ev);
		}
		return es;
	}
	
	/**
	 * Creates the stereotype instance from the stereotype Node.
	 *
	 * @param stereotype the stereotype
	 * @return the stereotype structure
	 */
	private StereotypeStructure createStereotype(Stereotype stereotype) {
		StereotypeStructure ss = null;
		EList<Property> attributes = stereotype.getOwnedAttributes();
		for (Property attribute : attributes) {
			if (!attribute.getLabel().equals("base_Operation")
					&& (!attribute.getLabel().equals("base_Class"))
					&& (!attribute.getLabel().equals("base_UseCase"))) {
				StereotypeAttribute sa = new StereotypeAttribute(
						attribute.getLabel(), this.getType(attribute),
						attribute.getVisibility().getLiteral());
				if(ss != null)
					ss.addAttributes(sa);
				// System.out.println(sa.toString());
			} else {
				try {
					ss = new StereotypeStructure(stereotype.getLabel(),
							this.getType(attribute));
				} catch (Exception e) {
					ss = new StereotypeStructure(stereotype.getLabel(), null);
				}
			}
		}
		return ss;
	}
	
	/**
	 * Gets the type of the attribute.
	 *
	 * @param attribute the attribute
	 * @return the type
	 */
	private String getType(Property attribute){
		String temp = attribute.getType().toString();
		String[] type = temp.split("#");
		if (type != null && type.length > 1){
			temp = type[1];
			int indexOf = temp.indexOf(")");
			temp = temp.substring(0,indexOf);
			//System.out.println(temp);
			return temp;
		}
		else
			return attribute.getType().getLabel();
	}
}
