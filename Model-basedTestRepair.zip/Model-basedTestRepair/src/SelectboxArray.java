import java.util.ArrayList;

public class SelectboxArray {
	ArrayList<String> value = new ArrayList<String>();
	public SelectboxArray(ArrayList<String> val) {
		value = val;
		
	}
	public ArrayList<String> getValue(){
		return value;
	}
	
}