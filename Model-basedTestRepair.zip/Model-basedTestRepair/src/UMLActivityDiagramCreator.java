
package mdse.emf.main;

import java.io.IOException;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.uml2.uml.Activity;
import org.eclipse.uml2.uml.ActivityEdge;
import org.eclipse.uml2.uml.ActivityNode;
import org.eclipse.uml2.uml.ActivityPartition;
import org.eclipse.uml2.uml.AggregationKind;
import org.eclipse.uml2.uml.Association;
import org.eclipse.uml2.uml.ControlFlow;
import org.eclipse.uml2.uml.InitialNode;
import org.eclipse.uml2.uml.Model;
import org.eclipse.uml2.uml.NamedElement;
import org.eclipse.uml2.uml.OpaqueExpression;
import org.eclipse.uml2.uml.Profile;
import org.eclipse.uml2.uml.Property;
import org.eclipse.uml2.uml.Stereotype;
import org.eclipse.uml2.uml.Type;
import org.eclipse.uml2.uml.UMLFactory;
import org.eclipse.uml2.uml.UMLPackage;
import org.eclipse.uml2.uml.ValueSpecification;
import org.eclipse.uml2.uml.VisibilityKind;
import org.eclipse.uml2.uml.internal.impl.ActivityImpl;
import org.eclipse.uml2.uml.resource.UMLResource;
import mdse.emf.util.UMLActivityDiagramFactory;
import mdse.emf.util.UMLClassDiagramFactory;
import mdse.emf.util.ModelLoader;
import mdse.emf.util.UMLActivityDiagramFactory;

/**
 * A class that creates UML class diagram.
 * 
 * @author Javaria
 * @version 1.0
 */

public class UMLActivityDiagramCreator {
	@SuppressWarnings({ "rawtypes", "unchecked" })
	static
	ModelLoader  md= new ModelLoader();
	public static void main(String[] args) {
		UMLActivityDiagramFactory umlElem = new UMLActivityDiagramFactory();
		String umlFilePath = "file:///C:/Users/Lenovo-FAST/Downloads/mdse-demos-master/EMF_Demo/OutputModel/Examples/Profile.profile.uml";

		//create package
		org.eclipse.uml2.uml.Package pkg = umlElem.createPackage("Demo Package");
		Profile testProfile= loadApplyProfile(umlFilePath,pkg);		
		
		Stereotype stereo = retrieveStereoType(testProfile,"TestCommand");
	    //create Activity
		umlElem.createActivityDia(pkg, "Login");   //ActivityName
		Activity act=(Activity) pkg.getPackagedElements().get(0);
		//create Nodes
		ActivityNode ni=act.createNode("start", UMLFactory.eINSTANCE.createInitialNode().eClass());
	//	ActivityNode n=act.createNode("one", UMLFactory.eINSTANCE.createOpaqueAction().eClass());
	      ActivityNode  n= createOpaqueAction(pkg, "one", VisibilityKind.PUBLIC_LITERAL, stereo);
		applyStereotype(n, stereo);
		ActivityNode nii=act.createNode("end", UMLFactory.eINSTANCE.createActivityFinalNode().eClass());
		act.getNodes().add(ni); //nodes added in activity 
		act.getNodes().add(n);
		act.getNodes().add(nii);
		
        //create edges
		ActivityEdge edge	=act.createEdge("hello", UMLFactory.eINSTANCE.createControlFlow().eClass());
		edge.setSource(ni);
		edge.setTarget(n);
	    ValueSpecification valuespec	=edge.createGuard("hell", null,  UMLFactory.eINSTANCE.createOpaqueExpression().eClass());
        ValueSpecification valuespec1	=edge.createWeight("bell", null, UMLFactory.eINSTANCE.createLiteralInteger().eClass());
        edge.setGuard(valuespec);
        edge.setWeight(valuespec1);
		act.getEdges().add(edge);  //edges added in activity
		
		
		
		
		
		
		
		
		ModelLoader umlModel = new ModelLoader();
		umlModel.loadResources();
		//save model
		save(pkg, URI.createURI("OutputModel").appendSegment("ActivityDiagram").appendFileExtension(UMLResource.FILE_EXTENSION));
	}
	
	
	
	public static void save(org.eclipse.uml2.uml.Package package_, URI uri) {
		Resource resource = new ResourceSetImpl().createResource(uri);
		resource.getContents().add(package_);

		try {
			resource.save(null);
			System.out.println("Saved .....");
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	
	
	public static void applyProfile(org.eclipse.uml2.uml.Package pkg_, Profile profile) {
		if (pkg_.applyProfile(profile) != null) {
			System.out.printf("Profile '%s' applied to package '%s'.",
					profile.getQualifiedName(), pkg_.getQualifiedName());
			System.out.println();
		}
	}
	public static Profile loadApplyProfile(String profile_Path, org.eclipse.uml2.uml.Package pkg_) {
		Profile profile = md.loadProfile(profile_Path);
		System.out.println("Profile : " + profile.getQualifiedName()
				+ " is Loaded Sucessfully");
		applyProfile(pkg_, profile);
		return profile;
	}

	public static Stereotype retrieveStereoType(Profile profile_,
			final String stereotype) {
		Stereotype conceptStereotype = profile_.getOwnedStereotype(stereotype);
		return conceptStereotype;
	}

	public static EObject applyStereotype(NamedElement namedElement,
			Stereotype stereotype) {
		EObject eob = null;
		
		if(namedElement == null || stereotype == null)
			return null;

		eob = namedElement.applyStereotype(stereotype);
		if (eob != null) {
			System.out.printf("Stereotype '%s' applied to element '%s'.",
					stereotype.getQualifiedName(),
					namedElement.getQualifiedName());
			System.out.println();
		}
		return eob;
	}
	public static org.eclipse.uml2.uml.ActivityNode createOpaqueAction (org.eclipse.uml2.uml.Package pkg_, String name, VisibilityKind kind, Stereotype st)
	{
		Activity act=(Activity) pkg_.getPackagedElements().get(0);
		//create Nodes
		ActivityNode ni=act.createNode(name, UMLFactory.eINSTANCE.createInitialNode().eClass());
		ni.applyStereotype(st);
		ni.setVisibility(kind);
		return ni;
	}
	}
	
